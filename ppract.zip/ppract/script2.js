let items = [];

function recordSubmission(record) {
 fetch('https://script.google.com/macros/s/AKfycbxqI9GhN5-B6_uRajMNtIJHuphUx3SajUsOSc8LnVt2kXeVp2jnJoSNNf0SeJJmpYv_nA/exec', {
 method: 'POST',
 body: JSON.stringify(record)
 }).catch(err => console.error('Could not record submission:', err));
}

function addItem(){

    let name = document.getElementById("itemName").value;
    let qty = parseInt(document.getElementById("itemQty").value);

    if(name === "" || isNaN(qty)){
        alert("Fill all fields");
        return;
    }

    items.push({ name, qty });

    recordSubmission({
        action: "ADD ITEM",
        name,
        qty
    });

    display();
}

function borrowItem(){

    let name = document.getElementById("borrowName").value;
    let qty = parseInt(document.getElementById("borrowQty").value);

    let item = items.find(i => i.name.toLowerCase() === name.toLowerCase());

    if(!item){
        alert("Item not found");
        return;
    }

    if(item.qty < qty){
        alert("Not enough stock");
        return;
    }

    item.qty -= qty;

    recordSubmission({action: "BORROW", name, qty, remaining: item.qty
    });

    display();
}

function returnItem(){

    let name = document.getElementById("returnName").value;
    let qty = parseInt(document.getElementById("returnQty").value);

    let item = items.find(i => i.name.toLowerCase() === name.toLowerCase());

    if(!item){
        alert("Item not found");
        return;
    }

    item.qty += qty;

    recordSubmission({action: "RETURN", name, qty, updatedStock: item.qty
    });

    display();
}

function display(){

    let table = document.getElementById("table");

    table.innerHTML = `
        <tr>
            <th>Item</th>
            <th>Stock</th>
            <th>Status</th>
        </tr>
    `;

    items.forEach(item => {

        let status = item.qty <= 2 ? "LOW STOCK" : "AVAILABLE";

        table.innerHTML += `
            <tr>
                <td>${item.name}</td>
                <td>${item.qty}</td>
                <td class="${item.qty <= 2 ? 'low' : 'ok'}">${status}</td>
            </tr>
        `;
    });
}
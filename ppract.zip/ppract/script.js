function recordSubmission(record) {
 fetch('https://script.google.com/macros/s/AKfycbzwpon07_RiU3aYoYlvhHSm922wWUPE_eq9aSfflFenSgRLrfm5OfakejgaljzvCdbr/exec', {
 method: 'POST',
 body: JSON.stringify(record)
 }).catch(err => console.error('Could not record submission:', err));
}

function evaluateStudent(){

    let name = document.getElementById("studentName").value;
    let age = document.getElementById("studentAge").value;
    let grade = parseFloat(document.getElementById("grade").value);
    let course = document.getElementById("course").value;

    let year = "";
    let years = document.getElementsByName("year");

    for(let i = 0; i < years.length; i++){
        if(years[i].checked){
            year = years[i].value;
        }
    }

    if(name == "" || age == "" || isNaN(grade) || year == ""){
        alert("Please complete all fields.");
        return;
    }

    let remarks = "";

    if(grade >= 90){
        remarks = "Excellent";
    }
    else if(grade >= 75){
        remarks = "Passed";
    }
    else{
        remarks = "Failed";
    }

    let message = "";

    switch(remarks){
        case "Excellent":
            message = "Outstanding performance!";
            break;
        case "Passed":
            message = "Congratulations!";
            break;
        case "Failed":
            message = "Better luck next semester.";
            break;
        default:
            message = "No message.";
    }

    document.querySelector("#title").textContent = "Evaluation Complete";

    let inputs = document.querySelectorAll("input");
    inputs.forEach(box => {
        box.style.background = "#fff";
    });

    let result = document.getElementsByClassName("result")[0];
    result.innerHTML = "";

    let heading = document.createElement("h2");
    heading.textContent = "Student Report";
    heading.setAttribute("class", "highlight");
    result.appendChild(heading);

    let table = document.createElement("table");

    table.innerHTML = `
        <tr><td>Name</td><td>${name}</td></tr>
        <tr><td>Age</td><td>${age}</td></tr>
        <tr><td>Course</td><td>${course}</td></tr>
        <tr><td>Year Level</td><td>${year}</td></tr>
        <tr><td>Grade</td><td>${grade}</td></tr>
        <tr><td>Remarks</td><td>${remarks}</td></tr>
        <tr><td>Message</td><td>${message}</td></tr>
    `;

    result.appendChild(table);

    recordSubmission({name, age, course, year, grade, remarks, message});

    let note = document.createElement("p");
    note.textContent = "Student successfully evaluated.";
    note.setAttribute("class", "note");
    result.appendChild(note);
}